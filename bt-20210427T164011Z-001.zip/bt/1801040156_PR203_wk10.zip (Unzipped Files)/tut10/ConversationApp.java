package tut10;

public class ConversationApp {
	private static ConversationApp instance;
	private ConversationApp() {
		
	}

	public static ConversationApp getInstance() {
		if (instance == null) {
			instance = new ConversationApp();
		}
		return instance;
	}

}