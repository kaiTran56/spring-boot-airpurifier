package tut10;

import java.util.Arrays;

public class Fibonacci {
	private Fibo[] a;
	
	public Fibonacci(int n) {
		a = new Fibo [n];
		new Fibo(n);
	}

	public void print() {
		System.out.println(Arrays.toString(a));
	}
	private class Fibo {
		private int result;
		
		public Fibo(int n) {
			if (n==1) {
				result=1;
			}
			else {
				result= (new Fibo(n - 1).result) + (new Fibo(n - 2).result);
			}
			a[n-1]=this;
		}
	public int getResult() {
		return result;	
}
	@Override
	public String toString() {
		return "Fibo [result=" + result + "]";
	}
	}
	
}

