package tut10;


import utils.AttrRef;
import utils.DOpt;
import utils.DomainConstraint;
import utils.OptType;

/**
 * 
 * @overview Represent the mobile phone
 * @attributes 
 * manName    String 
 * model      String 
 * color      Character char 
 * year       Integer int
 * guaranteed Boolean
 * @object A typical MobilePhone is c=<n, m, c, y, g>, where manName(n), model(m), color(c), year(y), guaranteed(g)
 * @abstract_properties
 *
 * mutable(manName)=false /\ optional(manName)=false /\ length(manName) = 10 /\ 
 * mutable(model)=false /\ optional(model)=false /\ length(model) = 20 /\
 * mutable(color)=true /\ optional(color)=true /\
 * mutable(year)=false /\ optional(year)=false /\ min(year) = 1973 /\ 
 * mutable(guaranteed)=true /\ optional(guaranteed)=true
 * 
 */
public class MobilePhone {

	@DomainConstraint(type = "String", mutable = false, optional = false, length = 10)
	private String manName;

	@DomainConstraint(type = "String", mutable = false, optional = false, length = 20)
	private String model;

	@DomainConstraint(type = "Character", mutable = true, optional = true)
	private char color;

	@DomainConstraint(type = "Integer", mutable = false, optional = false, min = 1973)
	private int year;

	@DomainConstraint(type = "Boolean", mutable = true, optional = true)
	private Boolean guaranteed;

	/**
	 * @effects
	 *  
	 * if manName, model, year are valid
	 *    initialize this as <manName, model, year>
	 * else
	 *    initialize this as <> and inform error
	 *    
	 */
	public MobilePhone(@AttrRef("manName") String manName, @AttrRef("model") String model, @AttrRef("year") int year) {
		if (!validateManName(manName)) {
			System.err.println("Invalid manufacturer name: " + manName);
			return;
		}
		if (!validateModel(model)) {
			System.err.println("Invalid model: " + model);
			return;
		}
		if (!validateYear(year)) {
			System.err.println("Invalid year: " + year);
			return;
		}

		this.manName = manName;
		this.model = model;
		this.year = year;
	}

	// overloading constructor
	/**
	 * @effects
	 *  
	 * if manName, model, year are valid
	 *    initialize this as < manName, model, color, year, guaranteed >
	 * else
	 *    initialize this as <> and inform error
	 *       
	 */
	public MobilePhone(
			@AttrRef("manName") String manName, 
			@AttrRef("model") String model, 
			@AttrRef("color") char color,
			@AttrRef("year") int year, 
			@AttrRef("guaranteed") Boolean guaranteed) {
		
		if (!validateManName(manName)) {
			System.err.println("Invalid manufacturer name: " + manName);
			return;
		}
		if (!validateModel(model)) {
			System.err.println("Invalid model: " + model);
			return;
		}
		if (!validateColor(color)) {
			System.err.println("Invalid color: " + color);
			return;
		}
		if (!validateYear(year)) {
			System.err.println("Invalid year: " + year);
			return;
		}
		if (!validateGuaranteed(guaranteed)) {
			System.err.println("Invalid guaranteed: " + guaranteed);
			return;
		}
		this.manName = manName;
		this.model = model;
		this.year = year;
		this.color = color;
		this.guaranteed = guaranteed;
		computeColorCode();
	}

	/**
	 * @param color the color to set
	 * @effects
	 * 
	 *   if color is valid
	 *     set this.color=color
	 *     return true
	 *   else
	 *     return false
	 *        
	 */
	@DOpt(type = OptType.Mutator)
	@AttrRef("color")
	public boolean setColor(char color) {
		if (validateColor(color)) {
			this.color = color;
			computeColorCode();
			return true;
		} else {
			return false;
		}
	}

	/**
	 * @param guaranteed the guaranteed to set
	 * @effects
	 *   if guaranteed is valid
	 *     set this.guaranteed=guaranteed
	 *     return true
	 *   else
	 *     return false
	 *         
	 */
	@DOpt(type = OptType.Mutator)
	@AttrRef("guaranteed")
	public boolean setGuaranteed(boolean guaranteed) {
		if (validateGuaranteed(guaranteed)) {
			this.guaranteed = guaranteed;
			return true;
		} else {
			return false;
		}
	}

	/**
	 * @effects return <tt>manName</tt>
	 */
	@DOpt(type = OptType.Observer)
	@AttrRef("manName")
	public String getManName() {
		return manName;
	}

	/**
	 * @effects return <tt>model</tt>
	 */
	@DOpt(type = OptType.Observer)
	@AttrRef("model")
	public String getModel() {
		return model;
	}

	/**
	 * @effects return <tt>color</tt>
	 */
	@DOpt(type = OptType.Observer)
	@AttrRef("color")
	public char getColor() {
		return color;
	}

	/**
	 * @effects return <tt>year</tt>
	 */
	@DOpt(type = OptType.Observer)
	@AttrRef("year")
	public int getYear() {
		return year;
	}

	/**
	 * @effects return <tt>guaranteed</tt>
	 */
	@DOpt(type = OptType.Observer)
	@AttrRef("guaranteed")
	public Boolean getGuaranteed() {
		return guaranteed;
	}


	/**
	 * @effects
	 * 
	 *          <pre>
	 *  if manName is valid 
	 *    return true 
	 *  else
	 *    return false
	 *          </pre>
	 */
	private boolean validateManName(String manName) {
		return (manName != null && manName.length() > 0 && manName.length() < 10);
	}

	/**
	 * @effects
	 * 
	 *          <pre>
	 *  if model is valid 
	 *    return true 
	 *  else
	 *    return false
	 *          </pre>
	 */
	private boolean validateModel(String model) {
		return (model != null && model.length() > 0 && model.length() < 20);
	}

	/**
	 * @effects
	 * 
	 *          <pre>
	 *  if color is valid 
	 *    return true 
	 *  else
	 *    return false
	 *          </pre>
	 */
	private boolean validateColor(char color) {
		if (color == '\u0000') {
			return false;
		}
			return true;
	}

	/**
	 * @effects
	 * 
	 *          <pre>
	 *  if year is valid 
	 *    return true 
	 *  else
	 *    return false
	 *          </pre>
	 */
	private boolean validateYear(int year) {
		return (year >= 1973);
	}
	
	/**
	 * @effects
	 * 
	 *          <pre>
	 *  if guaranteed is valid 
	 *    return true 
	 *  else
	 *    return false
	 *          </pre>
	 */
	private boolean validateGuaranteed(boolean guaranteed) {
		if(guaranteed==false) {
			return false;
		}
		return true;
	}
	
	private String colorCode;
	
	private void computeColorCode() {
		if (this.color == 'B') {
				this.colorCode = "#000FF";
		}
		if (this.color == 'Y') {
			this.colorCode = "#FFFF00";
		}
		if (this.color == 'G') {
			this.colorCode = "#00FF00";
		}
		if (this.color == 'O') {
			this.colorCode = "#FFA500";
		}
		if (this.color == 'R') {
			this.colorCode = "#FF0000";
		}
	}

	// defaults
	@Override
	public String toString() {
		return "MobilePhone [man name = " + manName + ", model = " + model + ", color = " + color + ", year = " + year + ", guaranteed = " + guaranteed + "]";
	}


	/**
	 * @effects
	 * 
	 *   if this satisfies abstract properties
	 *     return true 
	 *   else
	 *     return false
	 *      
	 */
	public boolean repOK() {
		return validateManName(manName) 
				&& validateModel(model) 
				&& validateColor(color) 
				&& validateYear(year)
				&& validateGuaranteed(guaranteed);
	}

}
