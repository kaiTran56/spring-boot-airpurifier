package tut9;

public class ConversationApp {

	public static void main(String[] args) {
		Person1 p = new Person1();
		
		// p.setName(null);
		// p.name = null;

	}

}
