package tut9;
import java.util.Vector;
public class IntSet {
	private Vector elements;
	
	public IntSet(Vector els) {
		if (!validateElements(els)) {
			System.err.println("Invalid els = " + els);
			return;
		}
		
		// elements = els;
		elements = new Vector<>();
		for (Object o : els) {
			elements.add(o);
		}
	}
	public Vector getElements() {
		Vector v = new Vector();
		for (Object o : this.elements) {
			v.add(o);
		}
		return v;
	}
	
	public void add(Object o) {
		if (!this.elements.contains(o)) {
			this.elements.add(o);
		}
	}
	
	private boolean validateElements(Vector elements) {
		for (int i = 0; i < elements.size(); i++) {
			for (int j = i + 1; j <elements.size(); j++) {
				if (elements.get(i) == elements.get(j)) {
					return false;
				}
			}
		}
		return true;
	}
	
	@Override
	public String toString() {
		return "InSet [elements = " + elements + "]";
	}
}
