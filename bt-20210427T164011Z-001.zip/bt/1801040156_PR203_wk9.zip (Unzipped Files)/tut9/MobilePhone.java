package tut9;
import utils.AttrRef;
import utils.DOpt;
import utils.DomainConstraint;
import utils.OptType;

/**
 * 
 * @overview Represent the mobile phone
 * @attributes 
 * manName     String 
 * model       String 
 * color       Character char 
 * year        Integer int
 * guaranteed  Boolean
 * @object A typical MobilePhone is c=<n, m, c, y, g>, where manName(n),
 *         model(m), color(c), year(y), guaranteed(g).
 * @abstract_properties
 * 
 * <pre>
 * mutable(manName)=false /\ optional(manName)=false /\
 * length(manName) = 10 /\ mutable(model)=false /\
 * optional(model)=false /\ length(model) = 20 /\
 * mutable(color)=true /\ optional(color)=true /\
 * mutable(year)=false /\ optional(year)=false /\ min(year)= 1973 /\ 
 * mutable(guaranteed)=true /\ optional(guaranteed)=true
 * 
 * <pre>
 */
public class MobilePhone {

	@DomainConstraint(type = "String", mutable = false, optional = false, length = 10)
	private String manName;

	@DomainConstraint(type = "String", mutable = false, optional = false, length = 20)
	private String model;

	@DomainConstraint(type = "Character", mutable = true, optional = true)
	private char color;

	@DomainConstraint(type = "Integer", mutable = false, optional = false, min = 1973)
	private int year;

	@DomainConstraint(type = "Boolean", mutable = true, optional = true)
	private Boolean guaranteed;

	/**
	 * @effects
	 * 
	 *          <pre>
	 *  
	 *  if manName, model, year are valid
	 *    initialise this as <manName, model, year>
	 *  else
	 *    initialise this as <> and inform error
	 *          </pre>
	 */
	public MobilePhone(
			@AttrRef("manName") String manName, 
			@AttrRef("model") String model, 
			@AttrRef("year") int year) {
		
		if (!validateManName(manName)) {
			System.err.println("Invalid manufacturer name: " + manName);
			return;
		}
		if (!validateModel(model)) {
			System.err.println("Invalid model: " + model);
			return;
		}
		if (!validateYear(year)) {
			System.err.println("Invalid year: " + year);
			return;
		}

		this.manName = manName;
		this.model = model;
		this.year = year;
	}
	
	// overloading constructor
	/**
	 * @effects
	 * 
	 * if manName, model, year are valid
	 *     initialise this as <manName, model, color, year, guaranteed>
	 * else
	 *     initialise this as <> and print out error
	 */
	public MobilePhone(@AttrRef("manName") String manName, @AttrRef("model") String model, @AttrRef("color") char color,
			@AttrRef("year") int year, @AttrRef("guaranteed") Boolean guaranteed) {
		if (!validateManName(manName)) {
			System.err.println("Invalid manufacturer name: " + manName);
			return;
		}
		if (!validateModel(model)) {
			System.err.println("Invalid model: " + model);
			return;
		}
		if (!validateColor(color)) {
			System.err.println("Invalid color: " + color);
			return;
		}
		if (!validateYear(year)) {
			System.err.println("Invalid year: " + year);
			return;
		}
		if (!validateGuaranteed(guaranteed)) {
			System.err.println("Invalid guaranteed: " + guaranteed);
			return;
		}
		this.manName = manName;
		this.model = model;
		this.year = year;
		this.color = color;
		this.guaranteed = guaranteed;
	}
	/**
	 * @param color the color to set
	 * @effects
	 * 
	 *          <pre>
	 *   if color is valid
	 *     set this.color=color
	 *     return true
	 *   else
	 *     return false
	 *          </pre>
	 */
	@DOpt(type = OptType.Mutator)
	@AttrRef("color")
	public void setColor(char color) {
		this.color = color;
	}

	/**
	 * @param guaranteed the guaranteed to set
	 * @effects
	 * 
	 *          <pre>
	 *   if guaranteed is valid
	 *     set this.guaranteed=guaranteed
	 *     return true
	 *   else
	 *     return false
	 *          </pre>
	 */
	@DOpt(type = OptType.Mutator)
	@AttrRef("guaranteed")
	public void setGuaranteed(boolean guaranteed) {
		this.guaranteed = guaranteed;
	}

	/**
	 * @effects return <tt>manName</tt>
	 */
	@DOpt(type = OptType.Observer)
	@AttrRef("manName")
	public String getManName() {
		return manName;
	}

	/**
	 * @effects return <tt>model</tt>
	 */
	@DOpt(type = OptType.Observer)
	@AttrRef("model")
	public String getModel() {
		return model;
	}

	/**
	 * @effects return <tt>color</tt>
	 */
	@DOpt(type = OptType.Observer)
	@AttrRef("color")
	public char getColor() {
		return color;
	}

	/**
	 * @effects return <tt>year</tt>
	 */
	@DOpt(type = OptType.Observer)
	@AttrRef("year")
	public int getYear() {
		return year;
	}

	/**
	 * @effects return <tt>guaranteed</tt>
	 */
	@DOpt(type = OptType.Observer)
	@AttrRef("guaranteed")
	public Boolean getGuaranteed() {
		return guaranteed;
	}

	// validating methods
	/**
	 * @effects
	 * 
	 *          <pre>
	 *  if manName is valid 
	 *    return true 
	 *  else
	 *    return false
	 *          </pre>
	 */
	private boolean validateManName(String manName) {
		return (manName != null && manName.length() > 0 && manName.length() < 10);
	}

	/**
	 * @effects
	 * 
	 *          <pre>
	 *  if model is valid 
	 *    return true 
	 *  else
	 *    return false
	 *          </pre>
	 */
	private boolean validateModel(String model) {
		return (model != null && model.length() > 0 && model.length() < 20);
	}

	/**
	 * @effects
	 * 
	 *          <pre>
	 *  if color is valid 
	 *    return true 
	 *  else
	 *    return false
	 *          </pre>
	 */
	private boolean validateColor(char color) {
		return true;
	}

	/**
	 * @effects
	 * 
	 *          <pre>
	 *  if year is valid 
	 *    return true 
	 *  else
	 *    return false
	 *          </pre>
	 */
	private boolean validateYear(int year) {
		return (year >= 1973);
	}

	private boolean validateGuaranteed(boolean guaranteed) {
		return true;
	}

	// defaults
	@Override
	public String toString() {
		return "MobilePhone [manName=" + manName + ", model=" + model + ", color=" + color + ", year=" + year
				+ ", guaranteed=" + guaranteed + "]";
	}

	// repOK
	/**
	 * @effects
	 * 
	 *          <pre>
	 *   if this satisfies abstract properties
	 *     return true 
	 *   else
	 *     return false
	 *          </pre>
	 */
	public boolean repOK() {
		return validateManName(manName) && validateModel(model) && validateColor(color) && validateYear(year)&& validateGuaranteed(guaranteed);
	}

	
	
}