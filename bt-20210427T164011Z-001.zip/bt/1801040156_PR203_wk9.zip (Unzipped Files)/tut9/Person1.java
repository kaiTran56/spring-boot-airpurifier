package tut9;

public class Person1 {
	private int id;
	private String name;
	
	public boolean setName(String name) {
		return false;
	}

}
