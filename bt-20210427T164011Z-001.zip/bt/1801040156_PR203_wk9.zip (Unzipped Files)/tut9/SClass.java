package tut9;
import java.util.Vector;
import userlib.DomainConstraint;
/**
 * @overview SClass is student class, which is a group of
 * students that studies together throughout a university degree.
 *
 * @attributes
 * id Integer int
 * name String
 * students Student[] Vector<Student>
 *
 * @object
 * A typical SClass is <i,n,s>, where id(i), name(n), students(s).
 * For example, <1,1c10,[]> is an SClass representing the student
 * class whose id is 1, whose name is 1c10, and whose student list is
 * empty.
 *
 * @abstract_properties
 * mutable(id)=true /\ optional(id)=false /\ min(id)=1 /\
 * mutable(name)=true /\ optional(name)=false /\ length(name)=20 /\
 * mutable(students)=true /\ optional(students)=false
 *
 */
public class SClass {
 @DomainConstraint(type="Integer",mutable=true,optional=false,min=1)
 private int id;
 @DomainConstraint(type="String",mutable=true,optional=false,length=20)
 private String name;
 @DomainConstraint(type="Vector",mutable=true,optional=false)
 private Vector students;

 /**
 * @effects
 * if name and students are valid
 * initialise this as <0,name,students>
 * else
 * print error message "Invalid input"
 */
 public SClass(String name, Vector students) {
 this.name = name;
 this.students = students;
 }

 /**
 * @effects
 * return id
 */
 public int getId() {
 return id;
 }

 /**
 * @effects
 * return name
 */
 public String getName() {
 return name;
 }

 /**
 * @effects
 * return students
 */
 public Vector getStudents() {
 return students;
 }

 @Override
 public String toString() {
 return "SClass:<"+id+","+name+","+students+">";
 }
}

 