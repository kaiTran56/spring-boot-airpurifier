package tut9;
import java.util.Vector;
public class Test {

	public static void main(String[] args) {
		Vector v = new Vector();
		v.add(5);
		v.add(6);
		v.add(7);
		
		IntSet i = new IntSet(v);
		System.out.println(i);
		
		// v.add(7);
		// System.out.println(v);
		// System.out.println(i);
		
		Vector elements = i.getElements();
		elements.add(7);
		
		System.out.println(elements);
		System.out.println(i);

	}

}
